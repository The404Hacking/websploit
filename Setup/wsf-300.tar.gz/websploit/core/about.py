#!/usr/bin/env python
#
# WebSploit Toolkit Menu module
# Created By 0x0ptim0us (Fardin Allahverdinazhand)
# Email : 0x0ptim0us@Gmail.Com

from core import wcolors
def about():
	print "\n"
	print(wcolors.color.RED + "Created By :" + wcolors.color.ENDC)
	print wcolors.color.CYAN + """
	Fardin Allahverdinazhand (0x0ptim0us)
	Location : Iran - Azarbayjan (Turkish)
	Twitter : @0x0ptim0us
	Report Bug : 0x0ptim0us@Gmail.Com
	""" + wcolors.color.ENDC
	print "\n"
	print(wcolors.color.RED + "Developer Team Not Available !\n" + wcolors.color.ENDC)
	

	
